from base import db
from base.com.vo.category_vo import CategoryVo


class CategoryDao:
    def insert_category(self, category_vo):
        db.session.add(category_vo)
        db.session.commit()

    def search_category(self):
        query = db.session.query(CategoryVo).all()
        # allparts2 = [dict(row) for row in query]
        db.session.commit()
        return query
