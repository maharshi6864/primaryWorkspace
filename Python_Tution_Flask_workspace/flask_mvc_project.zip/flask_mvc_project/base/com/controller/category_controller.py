from base import app
from flask import render_template, request, redirect
from base.com.vo.category_vo import CategoryVo
from base.com.dao.category_dao import CategoryDao


@app.route('/')
def addCategory():  # put application's code here
    return render_template("addCategory.html")


@app.route('/insertCategory', methods=["POST"])
def insertCategory():
    category_name = request.form.get('categoryName')
    category_description = request.form.get('categoryDes')
    category_vo = CategoryVo()
    category_dao = CategoryDao()
    category_vo.category_name = category_name
    category_vo.category_description = category_description
    category_dao.insert_category(category_vo)
    return redirect("/")


@app.route('/searchCategory')
def searchCategory():
    category_dao = CategoryDao()
    data = category_dao.search_category()
    print(data)
    return render_template("viewCategory.html",data=data)
